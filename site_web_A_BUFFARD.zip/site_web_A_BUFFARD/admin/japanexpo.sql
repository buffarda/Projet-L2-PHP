-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le :  sam. 08 déc. 2018 à 08:55
-- Version du serveur :  5.7.17
-- Version de PHP :  5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `japanexpo`
--

-- --------------------------------------------------------

--
-- Structure de la table `animation`
--

CREATE TABLE `animation` (
  `id_animation` int(11) NOT NULL,
  `nom` varchar(50) NOT NULL,
  `animateur1` varchar(50) DEFAULT NULL,
  `animateur2` varchar(50) DEFAULT NULL,
  `categorie` int(11) NOT NULL,
  `description` text,
  `jour` date NOT NULL,
  `heure_debut` time NOT NULL,
  `heure_fin` time NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `animation`
--

INSERT INTO `animation` (`id_animation`, `nom`, `animateur1`, `animateur2`, `categorie`, `description`, `jour`, `heure_debut`, `heure_fin`) VALUES
(1, 'cérémonie d\'ouverture officielle', 'Robert Paul', 'Camille Cerf', 1, 'cérémonie  de présentation du programme des journées.', '2018-12-26', '10:30:00', '11:15:00'),
(2, 'cérémonie d\'ouverture du concours de cosplay', 'Camille Cerf', 'Berkley Matthew', 1, NULL, '2018-12-26', '11:30:00', '12:00:00'),
(3, 'présentation et démonstration de jeux vidéos', 'Aonomi Eiji', NULL, 4, 'Aonomi Eiji nous faire l\'honneur  de sa présence et nous fait découvrir de nouvelles licences de jeux vidéos ! Ne ratez pas cela.', '2018-12-26', '14:00:00', '15:00:00'),
(4, 'Concert de musique moderne japonaise', 'Fenari Clint', NULL, 3, 'Fenari Clint se présente à la Japan Expo d\'Hiver 2018 pour nous faire découvrir la musique moderne japonaise.', '2018-12-26', '16:00:00', '17:30:00'),
(5, 'Tests de jeux live', 'Matthew Berkley', 'Paul Robert', 6, 'Des professionnels de jeux vidéos viennent nous montrer leurs talents en s\'affrontant sur des jeux tels que FIFA 2019 !', '2018-12-27', '11:00:00', '12:00:00'),
(6, 'Révélation de contenus de jeux !', 'Satoshi Tojiri', 'Paul Robert', 4, 'Satoshi Tojiri, le créateur de la saga Pokémon nous fait l\'honneur de nous présenter le contenu de sa future licence. Un magnifique remake des version Diamant et Perle vous attend !', '2018-12-27', '16:00:00', '17:30:00'),
(7, 'Première partie du concours de cosplay', 'Camille Cerf', 'Paul Robert', 3, 'Après la cérémonie d\'ouverture, voici venu le temps de la première partie du concours de cosplay. Nous verrons défiler des cosplayeurs et seulement 20 seront retenus !', '2018-12-28', '10:30:00', '12:00:00'),
(8, 'Distribution de nourritures japonaises', NULL, NULL, 1, 'Notre restaurant propose des échantillons de la bonne nourriture japonaise. Profitez des saveurs du pays du soleil levant !', '2018-12-28', '12:30:00', '13:30:00'),
(10, 'promotions et révélation de contenu', 'Paul Robert', NULL, 1, 'Si vous êtes restés jusque là, quelques surprises vous attendent, vous verrez ! Ensuite nous verrons le contenu de certains jeux vidéos.', '2018-12-28', '17:00:00', '18:00:00'),
(11, 'Dernier tour du concours de cosplay', 'Camille Cerf', 'Paul Robert', 3, '5 cosplayeurs seront vainqueurs et raffleuront le grand prix... Mais attention, tous les concurrents auront un lot de consolation.', '2018-12-29', '10:30:00', '12:00:00'),
(12, 'Concert de Zéphyr et Séréna', 'Zéphyr Létempe', 'Séréna Arrin', 7, 'Zéphyr Létempe et Séréna Arrin viennent mettre l\'ambiance à la Japan Expo !', '2018-12-29', '14:00:00', '15:30:00'),
(13, 'Demi-finale et finale du concours de jeux-vidéos', 'Paul Robert', NULL, 5, 'Un concours de jeux vidéos a eu lieu dans le coin des tests de jeux vidéos, la finale se passera en direct, Bonne chance aux participants !', '2018-12-29', '15:30:00', '17:00:00'),
(14, 'Remise des prix et cloture de la Japan Expo', 'Paul Robert', 'Camille Cerf', 1, 'Toutes choses ont une fin... nous cloturerons notre évènement en distribuant aux vainqueurs des différents concours leurs récompenses!', '2018-12-29', '17:00:00', '18:00:00');

-- --------------------------------------------------------

--
-- Structure de la table `categorie`
--

CREATE TABLE `categorie` (
  `id_categorie` int(11) NOT NULL,
  `nom_categ` varchar(50) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `categorie`
--

INSERT INTO `categorie` (`id_categorie`, `nom_categ`) VALUES
(1, 'cérémonie'),
(2, 'concert'),
(3, 'concours'),
(4, 'révélation de contenu'),
(5, 'démonstration'),
(6, 'Test jeux vidéos en live');

-- --------------------------------------------------------

--
-- Structure de la table `date`
--

CREATE TABLE `date` (
  `id_jour` int(11) NOT NULL,
  `date_jour` date NOT NULL DEFAULT '2018-12-26',
  `heure_ouverture` time NOT NULL DEFAULT '10:00:00',
  `heure_fermeture` time NOT NULL DEFAULT '18:00:00'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `date`
--

INSERT INTO `date` (`id_jour`, `date_jour`, `heure_ouverture`, `heure_fermeture`) VALUES
(1, '2018-12-26', '10:00:00', '18:00:00'),
(2, '2018-12-27', '10:00:00', '18:00:00'),
(3, '2018-12-28', '10:00:00', '18:00:00'),
(4, '2018-12-29', '10:00:00', '18:00:00');

-- --------------------------------------------------------

--
-- Structure de la table `membres`
--

CREATE TABLE `membres` (
  `id_membre` int(11) NOT NULL,
  `civilite` char(5) NOT NULL,
  `nom` varchar(50) NOT NULL,
  `prenom` varchar(50) NOT NULL,
  `statut` varchar(60) NOT NULL,
  `email` varchar(120) DEFAULT NULL,
  `mot_de_passe` varchar(120) NOT NULL,
  `adresse` varchar(120) DEFAULT NULL,
  `ville` varchar(75) DEFAULT NULL,
  `code_postal` int(5) DEFAULT NULL,
  `billet` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `membres`
--

INSERT INTO `membres` (`id_membre`, `civilite`, `nom`, `prenom`, `statut`, `email`, `mot_de_passe`, `adresse`, `ville`, `code_postal`, `billet`) VALUES
(1, 'M.', 'Aonuma', 'Eiji', 'créateur jeux vidéos', NULL, '', NULL, NULL, NULL, 0),
(2, 'M.', 'Robert', 'Paul', 'animateur présentateur', NULL, '', NULL, NULL, NULL, 0),
(3, 'Mme.', 'Richard', 'Alice', 'cosplayeur', NULL, '', NULL, NULL, NULL, 0),
(4, 'Melle', 'Hermann', 'Anaïs', 'cosplayeur', NULL, '', NULL, NULL, NULL, 0),
(5, 'Melle', 'Dupont', 'Clarence', 'animateur présentateur', NULL, '', NULL, NULL, NULL, 0),
(6, 'M.', 'Philippe', 'Arthur', 'cosplayeur', NULL, '', NULL, NULL, NULL, 0),
(7, 'M.', 'Tojiri', 'Satoshi', 'créateur de jeux vidéos', NULL, '', NULL, NULL, NULL, 0),
(8, 'M.', 'Bakuren', 'Akahiko', 'cosplayeur', NULL, '', NULL, NULL, NULL, 0),
(9, 'M.', 'Berkley', 'Matthew', 'juge de concours', NULL, '', NULL, NULL, NULL, 0),
(10, 'M.', 'Arthur', 'Anthony', 'cosplayeur', NULL, '', NULL, NULL, NULL, 0),
(11, 'Melle', 'Jones', 'Claire', 'cosplayeur', NULL, '', NULL, NULL, NULL, 0),
(12, 'Mme.', 'Cerf', 'Camille', 'animateur présentateur', NULL, '', NULL, NULL, NULL, 0),
(13, 'M.', 'Létempe', 'Zéphyr', 'Musicien', NULL, '', NULL, NULL, NULL, 0),
(14, 'Mme.', 'Arrin', 'Séréna', 'Musicien', NULL, '', NULL, NULL, NULL, 0),
(15, 'M.', 'Fenari', 'Clint', 'Musicien', NULL, '', NULL, NULL, NULL, 0),
(18, 'Mme.', 'titi', 'toto', 'visiteur', 'titi.toto@gmail.com', '110812f67fa1e1f0117f6f3d70241c1a42a7b07711a93c2477cc516d9042f9db', '99 rue du tutu', 'la rochelle', 99999, 0),
(21, 'M.', 'test', 'mail', 'visiteur', 'tuti@toto.com', '7ed8eda08e2d4a11a5459cc3453f54171591c0a39a113eaacc1f421deb5a9792', 'puet', 'pouet', 17000, 0),
(24, 'M.', 'test', 'mail', 'visiteur', 'titi.toto@gmail.com', '7ed8eda08e2d4a11a5459cc3453f54171591c0a39a113eaacc1f421deb5a9792', 'puet', 'pouet', 17000, 0),
(26, 'M.', 'dernier', 'test', 'visiteur', 'dernier@test.com', '110812f67fa1e1f0117f6f3d70241c1a42a7b07711a93c2477cc516d9042f9db', 'coucou', 'ville', 11111, 0);

-- --------------------------------------------------------

--
-- Structure de la table `pass`
--

CREATE TABLE `pass` (
  `id_pass` int(11) NOT NULL,
  `nom` varchar(60) NOT NULL,
  `heure_debut` time NOT NULL DEFAULT '10:00:00',
  `heure_fin` time NOT NULL DEFAULT '18:00:00',
  `date_validite` date NOT NULL,
  `prix` int(11) NOT NULL,
  `nbStock` int(11) NOT NULL DEFAULT '500'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `pass`
--

INSERT INTO `pass` (`id_pass`, `nom`, `heure_debut`, `heure_fin`, `date_validite`, `prix`, `nbStock`) VALUES
(1, 'pass prévente mercredi', '09:00:00', '18:00:00', '2018-12-26', 19, 497),
(2, 'pass achat sur place mercredi', '10:00:00', '18:00:00', '2018-12-26', 16, 500),
(3, 'pass prévente jeudi', '09:00:00', '18:00:00', '2018-12-27', 17, 500),
(4, 'pass achat sur place jeudi', '10:00:00', '18:00:00', '2018-12-27', 14, 496),
(5, 'pass prévente vendredi', '09:00:00', '18:00:00', '2018-12-28', 25, 496),
(6, 'pass achat sur place vendredi', '10:00:00', '18:00:00', '2018-12-28', 22, 500),
(7, 'pass prévente samedi', '09:00:00', '18:00:00', '2018-12-29', 21, 495),
(8, 'pass achat sur place samedi', '10:00:00', '18:00:00', '2018-12-29', 22, 500),
(9, 'pass 4 jours prévente', '09:00:00', '18:00:00', '0000-00-00', 62, 500),
(10, 'pass 4 jours achat sur place', '10:00:00', '18:00:00', '0000-00-00', 55, 499);

-- --------------------------------------------------------

--
-- Structure de la table `statut`
--

CREATE TABLE `statut` (
  `id_activite_statut` int(11) NOT NULL,
  `nom_statut` varchar(50) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `statut`
--

INSERT INTO `statut` (`id_activite_statut`, `nom_statut`) VALUES
(1, 'visiteur'),
(2, 'vendeur'),
(3, 'cosplayeur'),
(4, 'animateur présentateur'),
(5, 'créateur jeux vidéos'),
(6, 'juge de concours'),
(7, 'Musicien');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `animation`
--
ALTER TABLE `animation`
  ADD PRIMARY KEY (`id_animation`,`nom`),
  ADD KEY `id_categorie` (`categorie`),
  ADD KEY `id_jour` (`jour`);

--
-- Index pour la table `categorie`
--
ALTER TABLE `categorie`
  ADD PRIMARY KEY (`id_categorie`,`nom_categ`);

--
-- Index pour la table `date`
--
ALTER TABLE `date`
  ADD PRIMARY KEY (`id_jour`,`date_jour`);

--
-- Index pour la table `membres`
--
ALTER TABLE `membres`
  ADD PRIMARY KEY (`id_membre`),
  ADD KEY `nbStock` (`billet`);

--
-- Index pour la table `pass`
--
ALTER TABLE `pass`
  ADD PRIMARY KEY (`id_pass`);

--
-- Index pour la table `statut`
--
ALTER TABLE `statut`
  ADD PRIMARY KEY (`id_activite_statut`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `animation`
--
ALTER TABLE `animation`
  MODIFY `id_animation` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
--
-- AUTO_INCREMENT pour la table `categorie`
--
ALTER TABLE `categorie`
  MODIFY `id_categorie` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT pour la table `date`
--
ALTER TABLE `date`
  MODIFY `id_jour` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT pour la table `membres`
--
ALTER TABLE `membres`
  MODIFY `id_membre` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;
--
-- AUTO_INCREMENT pour la table `pass`
--
ALTER TABLE `pass`
  MODIFY `id_pass` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT pour la table `statut`
--
ALTER TABLE `statut`
  MODIFY `id_activite_statut` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
