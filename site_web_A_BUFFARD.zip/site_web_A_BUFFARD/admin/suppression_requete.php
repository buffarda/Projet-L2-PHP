<?php
    $sqlSuppr="SELECT * FROM animation";
    $infoSuppr=$connexion->query($sqlSuppr);
    $resSuppr=$infoSuppr->fetchAll(PDO::FETCH_OBJ);
        
        if(isset($_POST['nomSuppr']))
        {
            $IdSuppr=htmlspecialchars($_POST['nomSuppr']);
            echo $IdSuppr;
            
            if(!empty($_POST['nomSuppr'])){
                $Suppr="DELETE FROM `animation` WHERE `id`=$IdSuppr";
                $infosDel=$connexion->exec($Suppr);
            //var_dump($infos9);    
            } 
        }
        else
        {
            $nomSuppr="";
        }

    
?>