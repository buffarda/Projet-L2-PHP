<?php
    //---------------CREATION DE LA SESSION-----------//
    $identifiant='Utilisateur1';
    $mdp='95pnGZQPMop92';
    
    if(isset($_POST['User'])&&isset($_POST['password'])){
        if($identifiant==$_POST['User'] && $mdp==$_POST['password']){
            session_start();
            
            $_SESSION['User']=$_POST['User'];
            $_SESSION['password']=$_POST['password'];
            
        }
        else
        {
            echo "identifiant ou mot de passe inconnus";
        }
    }
    
    include 'connexion.php';
    $connexion=connexionBD();

    //--------------GESTION DE LA PAGE indexadmin.php- Ajout d'un event ---------//
    
    $sql1="SELECT distinct C.*, A.categorie 
            FROM categorie C, animation A
            WHERE C.id_categorie=A.categorie";
    $infos1=$connexion->query($sql1);
    $res1=$infos1->fetchAll(PDO::FETCH_OBJ);

    $sql2= "SELECT distinct D.*, A.jour
            FROM date D,  animation A
            WHERE D.date_jour=A.jour";
    $infos2=$connexion->query($sql2);
    $res2=$infos2->fetchAll(PDO::FETCH_OBJ);
    
    $sql3="SELECT * FROM date";
    $infos3=$connexion->query($sql3);
    $res3=$infos3->fetchAll(PDO::FETCH_OBJ);

        if(isset($_POST['nom']) && isset($_POST['animateur1']) && isset($_POST['animateur2']) && isset($_POST['categorie']) && isset($_POST['description']) && isset($_POST['jour']) && isset($_POST['heure_debut']) && isset($_POST['heure_fin']))
        {
            $nom=htmlspecialchars($_POST['nom']);
            $animateur1=htmlspecialchars($_POST['animateur1']);
            $animateur2=htmlspecialchars($_POST['animateur2']);
            $id_categorie= htmlspecialchars($_POST['categorie']);
            $description= htmlspecialchars($_POST['description']);
            $jour= htmlspecialchars($_POST['jour']);
            $heuredebut= htmlspecialchars($_POST['heure_debut']);
            $heurefin= htmlspecialchars($_POST['heure_fin']);
        
            if(!empty($_POST['nom']) && !empty($_POST['categorie']) && !empty($_POST['jour']) && !empty($_POST['heure_debut']) && !empty($_POST['heure_fin'])){
                $sql9="INSERT INTO animation VALUES  (null, '$nom', '$animateur1', '$animateur2', $id_categorie, '$description', '$jour', '$heuredebut', '$heurefin')";
                $infos9=$connexion->exec($sql9);
            //var_dump($infos9);
        } 
        }
        else
        {
            $nomSuppr="";
        }
    //--------------GESTION DE LA PAGE indexadmin.php- suppression d'un event ---------//
        $sqlSuppr="SELECT * FROM animation";
    $infoSuppr=$connexion->query($sqlSuppr);
    $resSuppr=$infoSuppr->fetchAll(PDO::FETCH_OBJ);
        
        if(isset($_POST['nomSuppr']))
        {
            $IdSuppr=htmlspecialchars($_POST['nomSuppr']);
            //echo $IdSuppr;
            
            if(!empty($_POST['nomSuppr'])){
                $Suppr="DELETE FROM `animation` WHERE `id_animation`=$IdSuppr";
                //echo $Suppr;
                $infosDel=$connexion->exec($Suppr);
                
            } 
        }
        else
        {
            $IdSuppr="";
        }







        //---------------GESTION DE LA PAGE indexadmin.php  /   modification.php - modification d'un event  -------------//

?>


<!DOCTYPE>
<html>

<head>
    <title>Japan Expo hiver</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-tofit=no">
    <link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
    <link rel="icon" href="favicon.png" type="image/png">
    <link rel="icon" href="animated_favicon.gif" type="image/gif">
    <link rel="stylesheet" href="styleadmin.css">
    <link rel="stylesheet" href="style/reset.css">
    <link href="https://fonts.googleapis.com/css?family=Indie+Flower" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet">
</head>

<body>
    <main>
        <h1>page Administrateur</h1>

        <form method="post" action="indexadmin.php">
            <fieldset>
                <legend>Ajouter un nouvel évènement</legend>
                <p>
                    <label for="nom">Nom de l'évènement*:</label>
                    <input type="text" name="nom">
                </p>
                <p>
                    <label for="animateur1">1er animateur:</label>
                    <input type="text" name="animateur1">
                </p>
                <p>
                    <label for="animateur2">2ème animateur:</label>
                    <input type="text" name="animateur2">
                </p>
                <p>
                    <label for="categorie">Catégorie*:</label>
                    <select name="categorie">
                        <?php foreach($res1 as $key=>$val): ;?>
                        <option value="<?=$val->id_categorie?>">
                            <?=$val->nom_categ?>
                        </option>
                        <?php endforeach; ?>
                    </select>
                </p>
                <p>
                    <label for="description">Description:</label>
                    <input type="text" name="description">
                </p>
                <p>
                    <label for="jour">Jour*:</label>
                    <select name="jour">
                        <?php foreach($res2 as $key=>$val): ?>
                        <option value="<?=$val->jour?>">
                            <?=$val->jour?>
                        </option>
                        <?php endforeach; ?>
                    </select>
                </p>
                <p>
                    <label for=heure_debut>Heure du début*: </label>
                    <input type="text" name="heure_debut">
                    <legend class="pres">écrire sous la forme heure:minute (00:00)</legend>
                </p>
                <p>
                    <label for="heure_fin">Heure de fin*:</label>
                    <input type="text" name="heure_fin">
                    <legend class="pres">écrire sous la forme heure:minute (00:00)</legend>
                </p>
            </fieldset>
            <input class="envoyer" type="submit" value="AJOUTER" name="envoyerAjout">
        </form>

        <form method="post" action="indexadmin.php">
            <fieldset>
                <legend>Supprimer un évènement</legend>

                <p>
                    <label for="IdSuppr">Nom de l'animation :</label>
                    <select name="IdSuppr">
                        <?php foreach($resSuppr as $key=>$val): ;?>
                        <option value="<?=$val->id_animation?>">
                            <?=$val->nom?>
                        </option>
                        <?php endforeach; ?>
                    </select>
                </p>

            </fieldset>
            <input class="envoyer" type="submit" value="SUPPRIMER" name="envoyerSuppr">
        </form>

        <form method="post" action="modification.php">
            <fieldset>
                <legend>Modifier un évènement</legend>

                <p>
                    <label for="Modif">Nom de l'animation :</label>
                    <select name="Modif">
                        <?php foreach($resSuppr as $key=>$val): ;?>
                        <option value="<?=$val->id_animation?>">
                            <?=$val->nom?>
                        </option>
                        <?php endforeach; ?>
                    </select>
                </p>
            </fieldset>
            <input class="envoyer" type="submit" value="SUIVANT" name="envoyerModif">
        </form>

        <p>
            <a href="..\index.php" style="color:white;">RETOUR A L'ACCUEIL</a>
        </p>
        <p>
            <a href="..\evenements.php" style="color:white;">ALLER A LA PAGE EVENEMENTS</a>
        </p>
    </main>

</body>

</html>
