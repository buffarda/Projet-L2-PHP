<?php
    define("SERVEUR","localhost"); 
        //chemin vers le serveur
    define("USER","root");
        //nom utilsateur
    define("MDP",""); 
        //mot de passe utilisateur
    define("BD","japanexpo");
        //nom de la base de données
    
    function connexionBD ($nomServeur=SERVEUR,$username=USER,$password=MDP,$nomBD=BD){
        try{
            $connex=new PDO('mysql:host='.$nomServeur.';dbname='.$nomBD,$username,$password);
            
            $connex->exec("SET CHARACTER SET utf8");
            //gestion des accents
            
            return $connex;
        }
        catch(Exception $e)
        {
            echo 'Erreur : '.$e->getMessage().'</br>';
            echo 'N° :'.$e->getCode();
            
            return NULL;
        }
    }

?>