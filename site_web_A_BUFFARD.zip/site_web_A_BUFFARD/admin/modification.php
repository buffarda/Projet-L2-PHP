<?php
    include 'connexion.php';
    $connexion=connexionBD();

    $sql1="SELECT distinct C.*, A.categorie 
        FROM categorie C, animation A
        WHERE C.id_categorie=A.categorie";
    $infos1=$connexion->query($sql1);
    $res1=$infos1->fetchAll(PDO::FETCH_OBJ);

    $sql2= "SELECT distinct D.*, A.jour
        FROM date D,  animation A
        WHERE D.date_jour=A.jour";
    $infos2=$connexion->query($sql2);
     $res2=$infos2->fetchAll(PDO::FETCH_OBJ);
    
    $sql3="SELECT * FROM date";
    $infos3=$connexion->query($sql3);
    $res3=$infos3->fetchAll(PDO::FETCH_OBJ);
    
    $tab=array();
    if(isset($_POST['Modif']))
    {
          
        $modif=htmlspecialchars($_POST['Modif']);
        //echo "modif = $modif";
        $sql="SELECT * FROM animation WHERE id_animation=$modif";
        //echo $sql;
        $info=$connexion->query($sql);
        $res=$info->fetchAll(PDO::FETCH_OBJ);
        
        
        foreach($res as $key=>$val)
        {
            foreach($val as $k=>$v)
            {
                $tab[]=$v;
            }
        }
        if(isset($_POST['modifNom']) && isset($_POST['modifAnimateur1']) && isset($_POST['modifAnimateur2']) && isset($_POST['modifCateg']) && isset($_POST['modifDescrip']) && isset($_POST['modifJour']) && isset($_POST['modifHeure_debut']) && isset($_POST['modifHeure_fin']))
        {
            //echo "modif = $modif";
            $nom=htmlspecialchars($_POST['modifNom']);
            $animateur1=htmlspecialchars($_POST['modifAnimateur1']);
            $animateur2=htmlspecialchars($_POST['modifAnimateur2']);
            $id_categorie= htmlspecialchars($_POST['modifCateg']);
            $description= htmlspecialchars($_POST['modifDescrip']);
            $jour= htmlspecialchars($_POST['modifJour']);
            $heuredebut= htmlspecialchars($_POST['modifHeure_debut']);
            $heurefin= htmlspecialchars($_POST['modifHeure_fin']);
            
            
            if(!empty($_POST['modifNom']) || !empty($_POST['modifCateg']) || !empty($_POST['modifJour']) || !empty($_POST['modifHeure_debut']) || !empty($_POST['modifHeure_fin'])){
                $sql9="UPDATE animation
                        SET id_animation=$modif,
                            nom='$nom',
                            animateur1='$animateur1',
                            animateur2='$animateur2',
                            categorie=$id_categorie,
                            description='$description',
                            jour='$jour',
                            heure_debut='$heuredebut',
                            heure_fin='$heurefin'
                        WHERE id_animation=$modif";
                echo $sql9;
                $infos9=$connexion->exec($sql9);
                var_dump($infos9);
                
                //header("location:indexadmin.php");
                echo "MODIFICON EFFECTUEE";
                
            }
        }
        else
        {
            $nom="";
            $animateur1="";
            $animateur2="";
            $id_categorie="";
            $description="";
            $jour="";
            $heuredebut="";
            $heurefin="";
        }
    }
    
?>


<!DOCTYPE>
<html>

<head>
    <title>Japan Expo hiver</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-tofit=no">
    <link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
    <link rel="icon" href="favicon.png" type="image/png">
    <link rel="icon" href="animated_favicon.gif" type="image/gif">
    <link rel="stylesheet" href="styleadmin.css">
    <link rel="stylesheet" href="style/reset.css">
    <link href="https://fonts.googleapis.com/css?family=Indie+Flower" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet">
</head>

<body>
    <main>
        <h1>Modifiez l'évènement :
            <?php foreach($res as $key=>$val):?>
            <?=$val->nom?>
            <?php endforeach;?>
        </h1>
        <form method="post" action="modification.php">
            <fieldset>
                <legend>Modification un nouvel évènement</legend>
                <input type="hidden" name="Modif" value="<?=$_POST['Modif']?>">
                <legend class="pres">Les champs qui sont déjà remplis correspondent aux <u><strong>nom</strong></u>, <u><strong>animateurs 1 et 2</strong></u>, <u><strong>catégorie</strong></u> , <u><strong>description</strong></u> , <u><strong>jour</strong></u>, <u><strong>heures de début et de fin</strong></u> de l'évènement que vous voulez modifier. Si vous ne voulez pas les changer, vous pouvez les laisser et ils seront enregistrés comme tel.</legend>
                <p>
                    <label for="modifNom">Nom de l'évènement*:</label>
                    <input type="text" name="modifNom" style="width:25%;" value="<?=$tab[1]?>" >
                </p>

                <p>
                    <label for="modifAnimateur1">1er animateur:</label>
                    <input type="text" name="modifAnimateur1" value="<?=$tab[2]?>">
                </p>
                <p>
                    <label for="modifAnimateur2">2ème animateur:</label>
                    <input type="text" name="modifAnimateur2" value="<?=$tab[3]?>">
                </p>
                <p>
                    <label for="modifCateg">Catégorie*:</label>
                    <input type="text" name="modifCateg" value="<?=$tab[4]?>">

                    <legend class="pres">
                        1 = cérémonie,<br>
                        2 = concert,<br>
                        3 = concours,<br>
                        4 = révélation de contenu,<br>
                        5 = démonstration, <br>
                        6 = tests de jeux vidéo en live
                    </legend>
                </p>
                <p>
                    <label for="modifDescrip">Description:</label>
                    <input type="text" name="modifDescrip" value="<?=$tab[5]?>" style="width:70%;">
                </p>
                <p>
                    <label for="modifJour">Jour*:</label>
                    <select name="modifJour">
                        <?php foreach($res2 as $key=>$val): ?>
                        <option value="<?=$val->jour?>">
                            <?=$val->jour?>
                        </option>
                        <?php endforeach; ?>
                    </select>
                </p>
                <p>
                    <label for=modifHeure_debut>Heure du début*: </label>
                    <input type="text" name="modifHeure_debut" value="<?=$tab[7]?>">
                    <legend class="pres">écrire sous la forme heure:minute (00:00)</legend>
                </p>
                <p>
                    <label for="modifHeure_fin">Heure de fin*:</label>
                    <input type="text" name="modifHeure_fin" value="<?=$tab[8]?>">
                    <legend class="pres">écrire sous la forme heure:minute (00:00)</legend>
                </p>
            </fieldset>
            <input type="submit" name="modifier" value="VALIDER">
        </form>
    </main>

</body>

</html>
