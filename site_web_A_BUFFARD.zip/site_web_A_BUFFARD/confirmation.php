<?php
    session_start();
    include 'connexion.php';
    $connexion=connexionBD();

?>


<!DOCTYPE>
<html>

<head>
    <title>Japan Expo hiver</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-tofit=no">
    <link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
    <link rel="icon" href="favicon.png" type="image/png">
    <link rel="icon" href="animated_favicon.gif" type="image/gif">
    <link rel="stylesheet" href="style/styleprinc.css">
    <link rel="stylesheet" href="style/stylep5.css">
    <link rel="stylesheet" href="style/reset.css">
    <link href="https://fonts.googleapis.com/css?family=Indie+Flower" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet">
</head>

<body>
    <?php include 'header.php' ?>

    <main>

        <article class="confirm">
            <p>
                Votre réservation a été prise en compte, nous vous envoyons votre commande dans les délais les plus courts
                <br>
                Nous vous souhaitons un agréable séjour à la Japan Expo 2018.
            </p>
            <p>
                <a href="index.php">Retour à l'accueil</a>

            </p>
            <p>
                <a href="evenements.php">Revoir les évènements</a>
            </p>
        </article>
    </main>

    <footer>
        <p><a href="admin/indexadmin.php">Admin</a><a href="indexApi.php">API</a></p>
        <p class="copyright">© 2018 BUF. UNIV LR- Tous droits réservés</p>
    </footer>
</body>

</html>
