<?php   
    session_start();
    include 'connexion.php';
    $connexion=connexionBD();
 
?>

<!DOCTYPE>
<html>

<head>
    <title>Japan Expo hiver</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-tofit=no">
    <link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
    <link rel="icon" href="favicon.png" type="image/png">
    <link rel="icon" href="animated_favicon.gif" type="image/gif">
    <link rel="stylesheet" href="style/styleprinc.css">
    <link rel="stylesheet" href="style/stylep1.css">
    <link rel="stylesheet" href="style/stylep3.css">
    <link rel="stylesheet" href="style/reset.css">
    <link href="https://fonts.googleapis.com/css?family=Indie+Flower" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet">
</head>

<body>
    <?php include 'header.php' ?>

    <main>

        <?php if(isset($_SESSION['email']) && !empty($_SESSION['email'])):?>
        <p class="bienv">Bienvenue <?=$_SESSION['civilite']?> <?=$_SESSION['nom']?> <?=$_SESSION['prenom']?></p> 
        <?php endif; ?>
       
        <h2>VOULEZ-VOUS :</h2>
        
        
        <p class="transit">
            <a href="index.php">Continuer à découvrir notre site</a>
        </p>

        <p class="transit">
            <a href="commande.php" class="a_transit">Réserver dès maintenant !</a>
        </p>
    </main>

    <footer>
        <p><a href="admin/indexadmin.php">Admin</a>
         <a href="indexApi.php">API</a></p>
        <p class="copyright">© 2018 BUF. UNIV LR- Tous droits réservés</p>
    </footer>
</body>

</html>