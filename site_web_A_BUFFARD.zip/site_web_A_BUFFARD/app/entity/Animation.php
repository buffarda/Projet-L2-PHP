<?php
/**
 * Created by PhpStorm.
 * User: abourmau
 * Date: 17/11/2018
 * Time: 15:27
 */

namespace app\entity;


class Animation{

  

    private $_id_animation;
    private $_nom;
    private $_animateur1;
    private $_animateur2;
    private $_categorie;
    private $_description;
    private $_jour;
    private $_heure_debut;
    private $_heure_fin;
    
    
    public function __construct(array $data)
    {
        $this->hydrate($data);
    }


    public function hydrate(array $donnees)
    {
        foreach ($donnees as $key => $value)
        {
            $method = 'set'.ucfirst($key);

            if (method_exists($this, $method))
            {
                $this->$method($value);

            }
        }
    }
    
    
    
    public function getIdAnimation()
    {
        return $this->_id_animation;
    }

    
    public function setId($nouvIdAnim)
    {
        $this->_id_animtion = $nouvIdAnim;
    }
    
    

    /**
     * @return mixed
     */
    public function getNom()
    {
        return $this->_nom;
    }

    /**
     * @param mixed $nom
     */
    public function setNom($nouvNom)
    {
        $this->_nom = $nouvNom;
    }
    
    

    

    public function setJour($nouvJour)
    {
        $this->_jour = $nouvJour;
    }

    public function getJour()
    {
        return $this->_jour;
    }
    
    
    
    
    public function getAnimateur1()
    {
        return $this->_animateur1;
    }

    
    public function setAnimateur1($nouvAnim1)
    {
        $this->_animateur1 = $nouvAnim1;
    }
    
    
    
    
    public function getAnimateur2()
    {
        return $this->_animateur2;
    }

    
    public function setAnimateur2($nouvAnim2)
    {
        $this->_animateur2 = $nouvAnim2;
    }
    
    
    
    public function getCategorie()
    {
        return $this->_categorie;
    }

    
    public function setCategorie($nouvCateg)
    {
        $this->_categorie = $nouvCateg;
    }
    
    
    public function getDescription()
    {
        return $this->_description;
    }

    
    public function setDescription($nouvDescrip)
    {
        $this->_description = $nouvDescrip;
    }
    
    public function getHeureDebut()
    {
        return $this->_heure_debut;
    }

    
    public function setHeureDebut($nouvHeureDeb)
    {
        $this->_heure_debut = $nouvHeureDeb;
    }
    
    
    public function getHeure_Fin()
    {
        return $this->_heure_fin;
    }

    
    public function setHeure_Fin($nouvHeureFin)
    {
        $this->_heure_fin = $nouvHeureFin;
    }
    
    
    
    
    public function __toString()
    {
        
        return $this->_nom. ", ".$this->_heure_debut." - ".$this->_heure_debut.", date : ".$this->_jour;
    }




}
