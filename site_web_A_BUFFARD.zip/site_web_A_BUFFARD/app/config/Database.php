<?php

namespace app\config;


class Database{
 
    // specify your own database credentials
    private $_host = "localhost";
    private $_db_name = "japanexpo";
    private $_username = "root";
    private $_password = "";
    private $_conn;
    
     
    // get the database connection
    public function getConnection(){
 
        $this->_conn = null;
 
        try{
            $this->_conn = new \PDO("mysql:host=" . $this->_host . ";dbname=" . $this->_db_name, $this->_username, $this->_password);
            $this->_conn->exec("set names utf8");
        }catch(PDOException $exception){
            echo "Connection error: " . $exception->getMessage();
        }
 
        return $this->_conn;
    }
}
?>