<?php
    namespace app\controller;

    use \app\model\AnimationModel;

    class ControllerAnimation{
        private $model;

        public function __construct()
        {
            $this->model=new AnimationModel();
        }


        public function getAll(){


            $content=$this->model->findAll();


            include('app/views/getAnimation.php');
        }


        public function getOne($id){
            $content=$this->model->findOne($id);

            include('app/views/getUnAnimation.php');

        }


        public function enregistrerAnimation($data){
            $content=$this->model->saveAnimation($data);

            include('app/views/enregistrerAnimation.php');

        }


}
?>