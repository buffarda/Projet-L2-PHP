<?php
    namespace app\controller\api;

    use \app\model\AnimationModel;

    class ControllerApi
    {
        private $model;

        public function __construct()
        {
            $this->model=new AnimationModel();

        }


        public function getAllApi(){

            $nbhits=$this->model->nbAnimation();
            $content=$this->model->findAllApi();

            include('app/views/viewApi.php');

        }
    }
?>