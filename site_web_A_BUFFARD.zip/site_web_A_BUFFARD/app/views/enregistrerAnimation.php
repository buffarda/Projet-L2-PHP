<h2>Nouvelle animation</h2>
<?php
if($content===1):?>
<p>L'animation  a été enregistrée</p>
<?php else: ?>
<p>L'animation n'a pas été enregistrée</p>
<?php endif; ?>
