
<h2>Animation demandée :</h2>
<?=$content ?>
