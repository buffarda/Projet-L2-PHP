<?php
   // var_dump($content);
 ?>

<h2>Toutes les animations : </h2>
<ul>
    <?php foreach($content as $uneAnimation):?>
    <li><?=$uneAnimation?></li>
    <?php endforeach;?>
</ul>