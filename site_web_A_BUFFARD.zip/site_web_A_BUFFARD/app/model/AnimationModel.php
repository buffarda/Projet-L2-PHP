<?php
/**
 * Created by PhpStorm.
 * User: abourmau
 * Date: 17/11/2018
 * Time: 15:39
 */
namespace app\model;

use \app\entity\Animation;
use \app\model\Model;


class AnimationModel extends Model{

    public function __construct()
    {
        $this->table="animation";
        parent::__construct($this->table);
    }


    public function findAll(){
        $arrayAnim=$this->find();

        $newTab=array();

        foreach ($arrayAnim as $uneAnimation){
            $newTab[]=new Animation($uneAnimation);
        }

        return $newTab;
        
    }


    public function findAllApi(){
        $arrayAnim=$this->find();
        
        return $arrayAnim;
        
       
    }


    public function findOne($id){
        $data=$this->read($id);

        return new Animation($data);
    }

    public function saveAnimation($data){

        return $this->save($data);

    }


    public function nbAnimation(){
        return count($this->findAll());
    }




}