<?php
/**
 * Created by PhpStorm.
 * User: abourmau
 * Date: 17/11/2018
 * Time: 15:34
 */

namespace app\model;

use app\config\Database;
use \PDO;



class Model{

    protected $table;

    private $connexion;



    public function __construct( ){

        $db=new Database();


        $this->connexion=$db->getConnection();
    }



    public function read($id)
    {
        //if($fields==null){$fields="*";}

        $sql="SELECT * FROM ".$this->table." WHERE id=".$id;
        /*$req=mysql_query($sql) or die(mysql_error());
        $data=mysql_fetch_assoc($req);*/


        $retour=$this->connexion->query($sql);
        $content=$retour->fetch(PDO::FETCH_ASSOC);

        return $content;

    }

   

    public function find ($data=array())
    {
        $conditions="1";
        $fields="*";
        $othertable="";
        if(isset($data["conditions"]))
        {
            $conditions=$data["conditions"];
        }
        if(isset($data["fields"])){$fields=$data["fields"];}
        if(isset($data["othertable"])){$othertable=", ".$data["othertable"];}
        
        $sql="SELECT $fields FROM ".$this->table." ".$othertable." WHERE $conditions";
        
        $prepa=$this->connexion->prepare($sql);
        
        
        $prepa->execute();
        
        $data=$prepa->fetchAll(PDO::FETCH_ASSOC);
        
        return $data;
        
    }
    
     public function save($data){

            $sql="INSERT INTO ".$this->table."(";
            foreach ($data as $key => $value) {
                unset($data["id"]);
                $sql.="`$key`,";
            }
            //suppression de la virgule
            $sql=substr($sql,0,-1);
            $sql.=" ) VALUES (";
            foreach ($data as $key => $value) {
                if(is_numeric($value))  $sql.=$value.",";
                else
                    $sql.="'$value',";
            }
            $sql=substr($sql,0,-1);
            $sql.=" )";


        $retour=$this->connexion->exec($sql);

        


        return $retour;
    }


   






}