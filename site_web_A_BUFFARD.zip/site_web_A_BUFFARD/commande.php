<?php
    session_start();
    include 'connexion.php';
    $connexion=connexionBD();
    
    //if(isset($_SESSION['']))


    
?>


<!DOCTYPE>
<html>

<head>
    <title>Japan Expo hiver</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-tofit=no">
    <link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
    <link rel="icon" href="favicon.png" type="image/png">
    <link rel="icon" href="animated_favicon.gif" type="image/gif">
    <link rel="stylesheet" href="style/styleprinc.css">
    <link rel="stylesheet" href="style/stylep5.css">
    <link rel="stylesheet" href="style/reset.css">
    <link href="https://fonts.googleapis.com/css?family=Indie+Flower" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet">
</head>

<body>
    <?php include 'header.php' ?>

    <main>
        <h2>INFOS SUR LES BILLETS</h2>
        <article>

            <table>
                <tr>
                    <th class="jours">jours :</th>

                    <th class="prévente">
                        préventes<sup><strong>*</strong></sup><br>
                        (à partir de 9h00)
                    </th>
                    <th class="achats">
                        Achats sur place<br>
                        (à partir de 10h00)
                    </th>
                </tr>
                <tr>
                    <th>mercredi<br>
                        26/12/2018
                    </th>
                    <td class="prix">
                        16€
                    </td>
                    <td class="prix">
                        19€
                    </td>
                </tr>
                <tr>
                    <th>jeudi<br>
                        27/12/2018
                    </th>
                    <td class="prix">
                        14€
                    </td>
                    <td class="prix">
                        17€
                    </td>
                </tr>
                <tr>
                    <th>
                        vendredi<br>
                        28/12/2018
                    </th>
                    <td class="prix">
                        22€
                    </td>
                    <td class="prix">
                        25€
                    </td>
                </tr>
                <tr>
                    <th>
                        samedi<br>
                        29/12/2018
                    </th>
                    <td class="prix">
                        18€
                    </td>
                    <td class="prix">
                        21€
                    </td>
                </tr>
                <tr>
                    <th>
                        PASS<br>
                        4 JOURS
                    </th>
                    <td class="prixMax">
                        55€
                    </td>
                    <td class="prixMax">
                        62€
                    </td>
                </tr>
            </table>
            <p>
                <sup><strong>*</strong></sup> en achetant un billet de prévente :
            </p>
            <ul>
                <li>
                    profitez d’<strong><em>une heure de plus sur le festival</em></strong> ! <br>
                    entrez <strong><em>à partir de 9h00 au lieu de 10h00</em></strong>, l'heure d’ouverture des caisses.
                </li>
                <li>
                    bénéficiez de <strong><em>tarifs réduits</em></strong> !
                </li>
            </ul>




            <?php if(isset($_SESSION['email'])):?>
            <p class="p_cmd"><a class="cmd" href="panier.php"><strong>RESERVER</strong></a></p>
            <?php endif; if(!isset($_SESSION['email'])):?>
            <p><a href="Inscription1.php">Intéressé? Inscrivez-vous dès maintenant</a></p>
            <?php endif; ?>
        </article>
    </main>
                

    <footer>
        <p><a href="admin/indexadmin.php">Admin</a>
        <a href="indexApi.php">API</a></p>
        <p class="copyright">© 2018 BUF. UNIV LR- Tous droits réservés</p>
    </footer>
</body>

</html>
