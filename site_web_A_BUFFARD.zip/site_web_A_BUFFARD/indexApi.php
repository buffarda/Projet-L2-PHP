<?php

    use app\entity;
    use app\controller\api\ControllerApi;
    function chargerClasse($classe)
    {
            $classe=str_replace('\\','/',$classe);
            require $classe . '.php';
    }

    spl_autoload_register('chargerClasse'); //fin Autoload


$cApi=new ControllerApi();

$content=$cApi->getAllApi();
    
   
?>
