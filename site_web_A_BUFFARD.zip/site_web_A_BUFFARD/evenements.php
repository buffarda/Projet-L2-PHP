<?php
    session_start();
    include 'connexion.php';            //inclusion du fichier connexion pour pouvoir connecter le site à la base de données
    $connexion=connexionBD();
    strftime("%R");
    

//-- requète pour le 1er jour de l'évènement
    $sql1="SELECT A.nom, A.animateur1, A.animateur2, A.description, A.jour, A.heure_debut, A.heure_fin FROM animation A, date D
    WHERE D.date_jour=A.jour
    AND D.date_jour='2018-12-26'";
    $infos1=$connexion->query($sql1);
    $res1=$infos1->fetchAll(PDO::FETCH_OBJ);


//-- requète pour le 2ème jour de l'évènement
    $sql2="SELECT A.nom, A.animateur1, A.animateur2, A.description, A.jour, A.heure_debut, A.heure_fin FROM animation A, date D
    WHERE D.date_jour=A.jour
    AND D.date_jour='2018-12-27'";
    $infos2=$connexion->query($sql2);
    $res2=$infos2->fetchAll(PDO::FETCH_OBJ);



//-- requète pour le 3ème jour de l'évènement
    $sql3="SELECT A.nom, A.animateur1, A.animateur2, A.description, A.jour, A.heure_debut, A.heure_fin FROM animation A, date D
    WHERE D.date_jour=A.jour
    AND D.date_jour='2018-12-28'";
    $infos3=$connexion->query($sql3);
    $res3=$infos3->fetchAll(PDO::FETCH_OBJ);

//-- requète pour le 4ème jour de l'évènement
    $sql4="SELECT A.nom, A.animateur1, A.animateur2, A.description, A.jour, A.heure_debut, A.heure_fin FROM animation A, date D
    WHERE D.date_jour=A.jour
    AND D.date_jour='2018-12-29'";
    $infos4=$connexion->query($sql4);
    $res4=$infos4->fetchAll(PDO::FETCH_OBJ);

    if(isset($_SESSION['billet']))
    {
        $date=htmlspecialchars($_SESSION['billet']);
        //echo "$date";
        $sql5="SELECT A.nom, A.animateur1, A.animateur2, A.description, A.jour, A.heure_debut, A.heure_fin FROM animation A, date D WHERE D.date_jour=A.jour
            AND D.date_jour='$date'";
        $info5=$connexion->query($sql5);
        $res5=$info5->fetchAll(PDO::FETCH_OBJ);
    }
?>


<!DOCTYPE>
<html>

<head>
    <title>Japan Expo hiver</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-tofit=no">
    <link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
    <link rel="icon" href="favicon.png" type="image/png">
    <link rel="icon" href="animated_favicon.gif" type="image/gif">
    <link rel="stylesheet" href="style/styleprinc.css">
    <link rel="stylesheet" href="style/stylep2.css">
    <link rel="stylesheet" href="style/reset.css">
    <link href="https://fonts.googleapis.com/css?family=Indie+Flower" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet">
</head>

<body>
    <?php include 'header.php' ?>

    <main>
        <article class="art_access">
            <h2>ACCESSIBILITE</h2>
            <img class="access" src="image/access.png" alt="accessibilite">
            <p style="font-size:105%;">
                

                Des places pour personnes à mobilité réduite sont mises à disposition tout autour du parc des expositions.
            </p>
            <br>
            <p style="margin:0px 50px 25px 50px">
                Le parking étant très étendu, si vous vous trouvez trop loin du parc, contactez le 09-54-47-98-00 , une équipe viendra aussi vite que possible pour vous emmener directement devant l'entrée.
            </p>
            <p style="margin:0px 50px 25px 50px">
                Le parc des expositions ne possède aucune marche pour y accéder, l'intérieur ne contient aucun étage, il n'y a donc pas besoin de s'inquiéter au sujet d'escaliers.
            </p>
        </article>
        
        <article class="ancres">
            <h2>SOMMAIRE</h2>
            <nav class="nav_ancre">
                <h3>ANIMATIONS</h3>
                <p>
                    <a href="#mercredi">mercredi 26 décembre</a>
                </p>
                <p>
                    <a href="#jeudi">jeudi 27 décembre</a>
                </p>
                <p>
                    <a href="#vendredi">vendredi 28 décembre</a>
                </p>
                <p>
                    <a href="#samedi">samedi 29 décembre</a>
                </p>
                <p>
                    <a href="jvjapan">les jeux vidéos présents à la Japan Expo d'hiver</a>
                </p>
            </nav>
        </article>

        <article id="mercredi" class="article_changer1">
            <h2>Mercredi 26 décembre</h2>
            <ul>
                <?php foreach($res1 as $key => $val): ?>
                <li>
                    <h3>
                        <?=$val->nom?>
                    </h3>
                    <p>
                        <strong>
                            <?=$val->heure_debut?> -
                            <?=$val->heure_fin?></strong><br>
                        animateur(s):
                        <?=$val->animateur1?>
                        <?php if(isset($val->animateur2)):?>
                        et
                        <?=$val->animateur2?>
                        <?php endif; ?>
                        <br>
                        <?=$val->description ?>
                    </p>
                </li>
                <?php endforeach; ?>
            </ul>
        </article>

        <article id="jeudi" class="article_changer2">
            <h2> Jeudi 27 décembre</h2>
            <ul>
                <?php foreach($res2 as $key => $val): ?>
                <li>
                    <h3>
                        <?=$val->nom?>
                    </h3>
                    <p>
                        <strong>
                            <?=$val->heure_debut?> -
                            <?=$val->heure_fin?></strong><br>
                        animateur(s):
                        <?=$val->animateur1?>
                        <?php if(isset($val->animateur2)):?>
                        et
                        <?=$val->animateur2?>
                        <?php endif; ?>
                        <br>
                        <?=$val->description ?>
                    </p>
                </li>
                <?php endforeach; ?>
            </ul>
        </article>

        <article id="vendredi" class="article_changer3">
            <h2> Vendredi 28 décembre</h2>
            <ul>
                <ul>
                    <?php foreach($res3 as $key => $val): ?>
                    <li>
                        <h3>
                            <?=$val->nom?>
                        </h3>
                        <p>
                            <strong>
                                <?=$val->heure_debut?> -
                                <?=$val->heure_fin?></strong><br>
                            animateur(s):
                            <?=$val->animateur1?>
                            <?php if(isset($val->animateur2)):?>
                            et
                            <?=$val->animateur2?>
                            <?php endif; ?>
                            <br>
                            <?=$val->description ?>
                        </p>
                    </li>
                    <?php endforeach; ?>
                </ul>
            </ul>
        </article>

        <article id="samedi" class="article_changer4">
            <h2> samedi 29 décembre</h2>
            <ul>
                <?php foreach($res4 as $key => $val): ?>
                <li>
                    <h3>
                        <?=$val->nom?>
                    </h3>
                    <p>
                        <strong>
                            <?=$val->heure_debut?> -
                            <?=$val->heure_fin?></strong><br>
                        animateur(s):
                        <?=$val->animateur1?>
                        <?php if(isset($val->animateur2)):?>
                        et
                        <?=$val->animateur2?>
                        <?php endif; ?>
                        <br>
                        <?=$val->description ?>
                    </p>
                </li>
                <?php endforeach; ?>
            </ul>
        </article>

        <article class="art_jv">
            <h2 id="jvjapan">LES JEUX PRESENTS A LA JAPAN EXPO D'HIVER</h2>
            <section style="font-size:125%; margin:7.5%;">
                <p>
                    Voici les jeux vidéos qui seront présentés et/ou jouables sur les différentes plateformes de jeux.
                </p>
            </section>
            <section>
                <h3>Jeux de PS4, Xbox One, PC</h3>
                <p>
                    <img src="image/One%20Piece.png">
                    One Piece World Seeker (PS4, Xbox One)
                </p>
                <p>
                    <img src="image/KingdomHearts3.jpg">
                    Kingdom Hearts III (PS4, Xbox One)
                </p>
                <p>
                    <img src="image/Anthem.jpg">
                    Anthem (PS4, Xbox One, PC)
                </p>
            </section>
            <section>
                <h3>Jeux Nintendo (Switch, Wii U, 3DS)</h3>
                <p>
                    <img src="image/SSB.jpg">
                    Super Smash Bros. Ultimate
                </p>
                <p>
                    <img src="image/marioBros.png">
                    Super Mario Bros.U DELUXE 
                </p>
            </section>
            <p style="margin:25px;">
                Et bien d'autres surprises...
            </p>
        </article>
    </main>

    <footer>
        <p><a href="admin/indexadmin.php">Admin</a>
         <a href="indexApi.php">API</a></p>
        <p class="copyright">© 2018 BUF. UNIV LR- Tous droits réservés</p>
    </footer>
</body>

</html>
