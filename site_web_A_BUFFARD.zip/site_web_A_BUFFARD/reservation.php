<?php
    session_start();
    include 'connexion.php';
    $connexion=connexionBD();


    if(isset($_SESSION['email']))
    {
        $sql="SELECT * FROM pass";
        $info=$connexion->query($sql);
        $res=$info->fetchAll(PDO::FETCH_OBJ);
        
        
        
        $mail=$_SESSION['email'];
        
        if(isset($_POST['1']) && isset($_POST['2']) && isset($_POST['3']) && isset($_POST['4']) && isset($_POST['5']) && isset($_POST['6']) && isset($_POST['7']) && isset($_POST['8']) && isset($_POST['9']))
        {
             $mercrediPrev=htmlspecialchars($_POST['1']);
             $mercAchat=htmlspecialchars($_POST['2']);
             $jeudiPrev=htmlspecialchars($_POST['3']);
             $jeudiAchat=htmlspecialchars($_POST['4']);
             $vendPrev=htmlspecialchars($_POST['5']);
             $vendAchat=htmlspecialchars($_POST['6']);
             $samediPrev=htmlspecialchars($_POST['7']);
             $samediAchat=htmlspecialchars($_POST['8']);
             $allPrev=htmlspecialchars($_POST['9']);
             $allAchat=htmlspecialchars($_POST['10']);
                
          //  echo $mercrediPrev;
            
            $billets=array(1 => $mercrediPrev,
                           2 => $mercAchat,
                           3 => $jeudiPrev,
                           4 => $jeudiAchat,
                           5 => $vendPrev,
                           6 => $vendAchat,
                           7 => $samediPrev,
                           8 =>$samediAchat,
                           9 =>$allPrev,
                           10 =>$allAchat
                          );
            
            
             $sql1="SELECT id_pass FROM pass";
             $info1=$connexion->query($sql1);
             $res1=$info1->fetchAll(PDO::FETCH_OBJ);
                
            $tab=array();
            $tabPrix=array();
            
            foreach($billets as $k=>$v)//les id envoyés par le select
            {
                
                    if($v>0)
                    {
                        $sql3="SELECT nom FROM pass 
                        WHERE id_pass=$k";
                        $info3=$connexion->query($sql3);
                        $res3=$info3->fetchAll(PDO::FETCH_OBJ);
                        
                        $sql4="SELECT prix FROM pass 
                        WHERE id_pass=$k";
                        $info4=$connexion->query($sql4);
                        $res4=$info4->fetchAll(PDO::FETCH_OBJ);
                        $i=0;
                        foreach($res3 as $key=>$val)
                        {
                            
                            $tab[]=$val->nom;
                        }
                        
                        foreach($res4 as $key=>$val)
                        {
                            $tabPrix[]=$val->prix;
                        }
                        
                        $sql2="UPDATE pass 
                                SET nbStock=nbStock-$v
                                WHERE id_pass=$k";
                        
                        $info2=$connexion->exec($sql2);
                    }
                    
                       
            }
            
        }
    }
    else
        {
            echo "<script type=\"text/javascript\">";
            echo "alert('Vous n'avez pas choisi de billet')";
            echo "</script>";
        }
    /*
    foreach($tab as $key=>$val)
    {
        echo "<pre>";
            echo $val;
        echo "</pre>";
    }
*/
?>


<!DOCTYPE>
<html>

<head>
    <title>Japan Expo hiver</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-tofit=no">
    <link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
    <link rel="icon" href="favicon.png" type="image/png">
    <link rel="icon" href="animated_favicon.gif" type="image/gif">
    <link rel="stylesheet" href="style/styleprinc.css">
    <link rel="stylesheet" href="style/stylep7.css">
    <link rel="stylesheet" href="style/reset.css">
    <link href="https://fonts.googleapis.com/css?family=Indie+Flower" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet">
</head>

<body>

    <?php include 'header.php'?>
    <main>

        <h2>RESERVATION</h2>
        <article>

            <form method="post" action="confirmation.php">

                <h3>VOUS AVEZ DONC CHOISI:</h3>
                <table class="table_form">
                    <tr>

                        <td>
                            <ul>
                                <?php foreach($tab as $key=> $val): ?>

                                <li>
                                    <?=$val?>
                                </li>

                                <?php endforeach; ?>
                            </ul>
                        </td>
                        <td>
                            <ul>
                                <?php foreach($tabPrix as $key=> $val): ?>
                                <li>
                                    <?=$val?>€
                                </li>
                                <?php endforeach; ?>
                            </ul>
                        </td>
                        <td>
                            <ul>
                                <?php foreach($billets as $key=> $val): ?>
                                <?php if($val>0): ?>

                                <li>
                                    x <?=$val?>
                                </li>

                                <?php endif; ?>
                                <?php endforeach; ?>
                            </ul>

                        </td>

                    </tr>
                </table>

                <p style="height:20px;">Total :
                    <?= array_sum($tabPrix) ?>€</p>
                <p class="paiement">
                    <img src="image/paiement.jpg" alt="paiement">
                    <img src="image/paypal.jpg" alt="paypal">
                    <br>
                    <label>titulaire:</label>
                    <input type="text" name="titulaire">
                    <br>
                    <label>Date validité: </label>
                    <input type="date" name="validite" class="date">
                    <br>
                    <label>pictogramme: </label>
                    <input type="text" name="picto">
                    
                    
                    <input type="hidden" name="billet" value="<?=$tab?>"> 
                </p>
                <p class="paiement2">
                    <input type="submit" name="envoyer" value="RECOMMENCER" class="billet_recommencer">
                    <input type="submit" name="envoyer" value="VALIDER" class="billet_paiement">
                </p>
            </form>

        </article>
    </main>

    <footer>
        <p><a href="admin/indexadmin.php">Admin</a>
         <a href="indexApi.php">API</a></p>
        <p class="copyright">© 2018 BUF. UNIV LR- Tous droits réservés</p>
    </footer>
</body>

</html>
