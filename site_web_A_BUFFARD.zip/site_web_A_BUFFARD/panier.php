<?php
    session_start();
    include 'connexion.php';
    $connexion=connexionBD();

    
    if(isset($_SESSION['email']))
    {
        $sql="SELECT * FROM pass";
        $info=$connexion->query($sql);
        $res=$info->fetchAll(PDO::FETCH_OBJ);
        
        $mail=$_SESSION['email'];
    }
?>


<!DOCTYPE>
<html>

<head>
    <title>Japan Expo hiver</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-tofit=no">
    <link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
    <link rel="icon" href="favicon.png" type="image/png">
    <link rel="icon" href="animated_favicon.gif" type="image/gif">
    <link rel="stylesheet" href="style/styleprinc.css">
    <link rel="stylesheet" href="style/stylep7.css">
    <link rel="stylesheet" href="style/reset.css">
    <link href="https://fonts.googleapis.com/css?family=Indie+Flower" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet">
</head>

<body>
    <?php include 'header.php' ?>

    <main>
        <h2>BILLETS</h2>
        <article>
            <form method="post" action="reservation.php">
                <table>
                    <tr>
                        <td class="td1">
                            <ul>
                                <?php foreach($res as $key=>$val):?>
                                <li>
                                    <p>
                                        <?=$val->nom?>
                                    </p>
                                </li>
                                <?php endforeach; ?>
                            </ul>
                        </td>
                        <td class="td2">
                            <ul>
                                <?php foreach($res as $key=>$val):?>
                                <li>
                                    <p>
                                        <?=$val->prix?>€
                                    </p>
                                </li>
                                <?php endforeach; ?>
                            </ul>
                        </td>
                        <td class="td3">
                            <ul>
                                <?php foreach($res as $key=>$val): ?>
                                <li>
                                    <select name="<?=$val->id_pass?>" class="billet_paiement">
                                        <?php for($i=0;$i<10;$i++): ?>
                                        <option value="<?=$i?>">
                                            <strong>
                                                <?=$i?>
                                            </strong>
                                        </option>
                                        <?php endfor; ?>
                                    </select>
                                </li>
                                <?php endforeach; ?>
                            </ul>
                        </td>
                    </tr>
                </table>
                <input type="submit" name="envoyer" value="SUIVANT">
            </form>
        </article>
    </main>

    <footer>
        <p><a href="admin/indexadmin.php">Admin</a>
         <a href="indexApi.php">API</a></p>
        <p class="copyright">© 2018 BUF. UNIV LR- Tous droits réservés</p>
    </footer>
</body>

</html>
