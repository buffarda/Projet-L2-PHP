<?php
    include 'connexion.php';
    $connexion=connexionBD();

    $sql="SELECT distinct civilite FROM membres";
    $info=$connexion->query($sql);
    $res=$info->fetchAll(PDO::FETCH_OBJ);
    
    

    if(isset($_POST['civilite']) && isset($_POST['nom']) && isset($_POST['prenom']) && isset($_POST['email']) && isset($_POST['mdp']) && isset($_POST['adresse']) && isset($_POST['codePostal']) && isset($_POST['ville']))
    {
        $civilite=htmlspecialchars($_POST['civilite']);
        $nom=htmlspecialchars($_POST['nom']);
        $prenom=htmlspecialchars($_POST['prenom']);
        $email=htmlspecialchars($_POST['email']);
        $mdp=htmlspecialchars(hash('sha256', $_POST['mdp']));
        $adresse=htmlspecialchars($_POST['adresse']);
        $codePostal=htmlspecialchars($_POST['codePostal']);
        $ville=htmlspecialchars($_POST['ville']);
        
        if(!empty($_POST['civilite']) && !empty($_POST['nom']) && !empty($_POST['prenom']) && !empty($_POST['email']) && !empty($_POST['mdp']) && !empty($_POST['adresse']) && !empty($_POST['codePostal']) && !empty($_POST['ville']))
        {
            
                $sql_insert="INSERT INTO membres VALUES (null, '$civilite', '$nom', '$prenom', 'visiteur', '$email', '$mdp', '$adresse', '$ville', $codePostal, 0)";
                $info_insert=$connexion->exec($sql_insert);
                
                header("location:login.php");
        }
        else
        {
            echo "<script type=\"text/javascript\">";
            echo "alert('Vous avez oublié de remplir un ou plusieurs champs');";
            echo "window.history.back();";
            echo "</script>";
        }        
    }
    else
    {
        $civilite="";
        $nom="";
        $prenom="";
        $email="";
        $mdp="";
        $adresse="";
        $codePostal="";
        $ville="";
    }
?>

<!DOCTYPE>
<html>

<head>
    <title>Japan Expo hiver</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-tofit=no">
    <link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
    <link rel="icon" href="favicon.png" type="image/png">
    <link rel="icon" href="animated_favicon.gif" type="image/gif">
    <link rel="stylesheet" href="style/styleprinc.css">
    <link rel="stylesheet" href="style/stylep3.css">
    <link rel="stylesheet" href="style/reset.css">
    <link href="https://fonts.googleapis.com/css?family=Indie+Flower" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet">
</head>

<body>
    <?php include 'header.php' ?>

    <main>

        <h2>INSCRIPTION</h2>
        <form method="post" action="Inscription1.php">

            <p>
                <label for="sexe">Civilité :</label>
                <select name="civilite" id="civilite">
                    <?php foreach($res as $key=>$val): ?>
                    <option value="<?=$val->civilite?>">
                        <?=$val->civilite?>
                    </option>
                    <?php endforeach; ?>
                </select>

            </p>
            <p>
                <label for="nom">Nom :</label>
                <input type="text" name="nom" id="nom">
            </p>
            <p>

                <label for="prenom">Prenom :</label>
                <input type="text" name="prenom" id="prenom">
            </p>
            <p>
                <label for="email">Adresse mail :</label>
                <input type="email" name="email" id="email">

            </p>
            <p>
                <label> Mot de passe :</label>
                <input type="password" name="mdp" id="mdp">
            </p>
            <p>
                <label for="adresse">Adresse:</label>
                <input type="text" name="adresse" id="adresse">
            </p>
            <p>
                <label for="codePostal">Code Postal:</label>
                <input type="text" name="codePostal" id="cp">
            </p>
            <p>
                <label>Ville:</label>
                <input type="text" name="ville" id="ville">
            </p>

            <input type="submit" name="confirmer" value="ENVOYER" id="conf">

        </form>

        <p>
            <a href="login.php">Déjà inscrit? Cliquez ici pour vous connecter </a>
        </p>
    </main>

    <footer>
        <p><a href="admin/indexadmin.php">Admin</a>
            <a href="indexApi.php">API</a></p>
        <p class="copyright">© 2018 BUF. UNIV LR- Tous droits réservés</p>
    </footer>
</body>

</html>
