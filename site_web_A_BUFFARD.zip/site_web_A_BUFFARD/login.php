<?php
    session_start();
    include 'connexion.php';
    $connexion=connexionBD();

    if(!empty($_POST['email']) && !empty($_POST['mdp']) && isset($_POST['email']) && isset($_POST['mdp']))
    {
        $mail=trim(addslashes(htmlspecialchars($_POST['email'])));
        $mdp=trim(addslashes(htmlspecialchars(hash('sha256',$_POST['mdp']))));
        
        $sql="SELECT * FROM membres WHERE email='$mail'";
        $info=$connexion->query($sql);
        $count=$info->rowCount();
        
        if($count==1)
        {
            $resClient=$info->fetch(PDO::FETCH_OBJ);
            if($mdp===$resClient->mot_de_passe)
            {
                $_SESSION['email']=$resClient->email;
                $_SESSION['nom']=$resClient->nom;
                $_SESSION['prenom']=$resClient->prenom;
                $_SESSION['civilite']=$resClient->civilite;
                $_SESSION['adresse']=$resClient->adresse;
                $_SESSION['ville']=$resClient->ville;
                $_SESSION['code_postal']=$resClient->code_postal;
                $_SESSION['billet']=$resClient->billet;
                header("location:transition.php");
            }
            else
            {
                echo "<script type=\"text/javascript\">";
                echo "alert('le mot de passe saisi est incorrect.')";
                echo "</script>";
            }
        }
        else
        {
            echo "<script type=\"text/javascript\">";
            echo "alert('<l\'adresse mail saisie est incorrecte.</p>')";
            echo "</script>";
        }
    }
    else
    {
        $mail="";
        $mdp="";
    }
?>

<!DOCTYPE>
<html>

<head>
    <title>Japan Expo hiver</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-tofit=no">
    <link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
    <link rel="icon" href="favicon.png" type="image/png">
    <link rel="icon" href="animated_favicon.gif" type="image/gif">
    <link rel="stylesheet" href="style/styleprinc.css">
    <link rel="stylesheet" href="style/stylep4.css">
    <link rel="stylesheet" href="style/reset.css">
    <link href="https://fonts.googleapis.com/css?family=Indie+Flower" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet">
</head>

<body>
    <?php include 'header.php' ?>

    <main>
      <!--
       <?php if(isset($_SESSION['email']) && !empty($_SESSION['email'])):?>
           <?php foreach($_SESSION as $key=>$val):?>
           <p><?=$val?></p>
           <?php endforeach; endif; ?>
        -->
        <h2>CONNECTEZ-VOUS</h2>
        <form method="post" action="login.php">

            <p>
                <label>Adresse mail : </label>
                <input type="email" name="email" id="email">
            </p>
            <p>
                <label>mot de passe : </label>
                <input type="password" name="mdp" id="mdp">
            </p>
            <p>
                <input type="submit" name="confirmer" value="CONNEXION" id="conf">
            </p>
        </form>

        <p>
            <a href="Inscription1.php">pas encore inscrit? Cliquez ici</a>
        </p>
    </main>

    <footer>
        <p><a href="admin/indexadmin.php">Admin</a>
         <a href="indexApi.php">API</a></p>
        <p class="copyright">© 2018 BUF. UNIV LR- Tous droits réservés</p>
    </footer>
</body>

</html>
