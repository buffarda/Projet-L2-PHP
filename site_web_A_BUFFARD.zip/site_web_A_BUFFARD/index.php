<?php
    session_start();
?>

<!DOCTYPE>
<html>

<head>
    <title>Japan Expo hiver</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-tofit=no">
    <link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
    <link rel="icon" href="favicon.png" type="image/png">
    <link rel="icon" href="animated_favicon.gif" type="image/gif">
    <link rel="stylesheet" href="style/styleprinc.css">
    <link rel="stylesheet" href="style/stylep1.css">
    <link rel="stylesheet" href="style/reset.css">
    <link href="https://fonts.googleapis.com/css?family=Indie+Flower" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet">
</head>

<body>
    <?php include 'header.php' ?>

    <main>

        <article class="article1">

            <section class="article_sect1">
                <h2>Informations pratiques</h2>
                <ul class="list-infos">

                    <li class="info">
                        <p><strong>Dates :</strong><br>
                            Du 27 au 30 décembre</p>
                    </li>
                    <li class="info">

                        <p> <strong>Lieu :</strong><br>
                            <a target="_blank" href="https://www.google.fr/maps/place/Parc+des+expositions+Paris+Nord+Villepinte/@48.9718878,2.5183701,3a,75y,90t/data=!3m8!1e2!3m6!1sAF1QipN0weYhkxIrx9STauej9EJEQUax75xa_FPzaKOy!2e10!3e12!6shttps:%2F%2Flh5.googleusercontent.com%2Fp%2FAF1QipN0weYhkxIrx9STauej9EJEQUax75xa_FPzaKOy%3Dw129-h86-k-no!7i2048!8i1365!4m18!1m12!4m11!1m3!2m2!1d2.5165343!2d48.9723581!1m6!1m2!1s0x47e61423545865ff:0x19d8add2537a716a!2sParc+des+expositions+Paris+Nord+Villepinte,+ZAC+Paris+Nord+2,+93420+Villepinte!2m2!1d2.516543!2d48.972348!3m4!1s0x47e61423545865ff:0x19d8add2537a716a!8m2!3d48.972348!4d2.516543">Parc des expositions de Paris-Nord Villepinte</a></p>
                    </li>
                    <li class="info">
                        <p>
                            <strong>Horaires :</strong><br>
                            <a href="commande.php">Horaires et billeterie</a>
                        </p>
                    </li>
                    <li class="info">
                        <p>
                            <a href="evenements.php">Accessibilité</a>
                        </p>
                    </li>
                    <li class="contact_us">
                        <a href="#formulaire">NOUS CONTACTER</a>
                    </li>
                </ul>

            </section>
            <section class="article_sect2">
                <img src="image/paris-nord-villepinte.jpg" alt="image parc expo">
            </section>
        </article>


        <article class="article2">

            <h2><strong>AU PROGRAMME</strong></h2>
            <section>

                <img src="image/SSB.jpg" alt="SSB">
                <h3>TESTS DE JEUX VIDEOS</h3>
                <a class="en_savoir_plus" href="#plus1"><strong>En savoir plus</strong></a>
            </section>

            <section>
                <img src="image/cosplay3.jpg" alt="cosplay">
                <h3>CONCOURS DE COSPLAY</h3>
                <a class="en_savoir_plus" href="#plus2"><strong>En savoir plus</strong></a>
            </section>

            <section>
                <img src="image/marchand_.jpg" alt="stands">
                <h3>DE NOMBREUX STANDS</h3>
                <a class="en_savoir_plus" href="#plus3"><strong>En savoir plus</strong></a>
            </section>

            <section>
                <img class="japan" src="image/japan.jpg" alt="culture jap">
                <h3>CULTURE JAPONAISE</h3>
                <a class="en_savoir_plus" href="#plus4"><strong>En savoir plus</strong></a>
            </section>

        </article>

        <article class="article3">
            <section class="article_sect1">

                <img src="image/marioBros.png" alt="mario">

            </section>
            <section class="article_sect2" id="plus1">
                <h2>Des tests de jeux</h2>
                <p>Une salle entière est consacrée aux jeux vidéos dont la sortie est proche:</p>
                <ul>
                    <li>Switch :
                        <ul>
                            <li> Super Smash Bros. ULTIMATE</li>
                            <li> Super Mario Bros. U</li>
                            <li> ...</li>
                        </ul>
                    </li>
                    <li>PS4 :
                        <ul>
                            <li> One Piece : World Seeker</li>
                            <li> FIFA 2020</li>
                            <li> ...</li>
                        </ul>
                    </li>
                    <li>XBOX ONE :
                        <ul>
                            <li> Halo Infinite</li>
                            <li> Dead or Alive 6</li>
                        </ul>
                    </li>
                </ul>
            </section>
        </article>

        <article class="article4" id="plus2">

            <section class="article_sect1">
                <h2>Concours de cosplay</h2>
                <p>
                    Inscrivez-vous au concours de cosplay ouvert à tous, que vous soyez professionnel comme amateur !<br>
                    Le but est de s'amuser après tout !
                </p>

            </section>
            <section class="article_sect2">
                <img src="image/Japan-Expo-cosplay-12.jpg" alt="présentation cosplay">
            </section>
        </article>

        <article class="article5" id="plus3">

            <section class="article_sect1">
                <img src="image/plan2.png" alt="plan japan expo">


            </section>
            <section class="article_sect2">
                <h2>De nombreuses découvertes !</h2>
                <p>
                    La Japan Expo offre la possibilité de découvrir:
                </p>
                <ul>
                    <li>
                        stands de ventes de goodies
                    </li>
                    <li>
                        salles de jeux vidéos
                    </li>
                    <li>
                        de nombreux mangas
                    </li>
                    <li>
                        arts traditionnels japonais
                    </li>
                    <li>
                        ...
                    </li>
                </ul>
                <a href="image/plan2.png" download="plan"><strong>Agrandir le plan</strong></a>
            </section>
        </article>

        <article class="article6" id="plus4">

            <section class="article_sect1">
                <h2>Culture Japonaise</h2>
                <p>
                    Le Japon est un archipel qui regorge d'une culture extraordinaire.<br> Pendant 4 jours, la Japan Expo vous offre la possibilité de découvrire les coutumes japonaise.
                </p>

            </section>
            <section class="article_sect2">
                <img src="image/culturejap.png" alt="culture japonaise">
            </section>
        </article>

        <article class="article7" id="contact_us">
            <h2>Vous voulez nous poser une question ou nous faire un commentaire? Nous vous écoutons</h2>
            <form id="formulaire" method="post" action="#">
                <p>
                    <label for="nom">Nom </label>
                    <input type="text" name="nom">
                    <label for="prenom">Prenom</label>
                    <input type="text" name="prenom">
                </p>
                <p>

                </p>
                <p>
                    <label for="email">Adresse mail *</label>
                    <input type="email" name="email">
                </p>
                <p>
                    <label>Commentaire *</label><br>
                    <textarea name="commentaire" rows="8" cols="80">
                    </textarea>
                </p>
                <p class="envoyer">
                    <input type="submit" value="ENVOYER">
                </p>
            </form>
        </article>
    </main>

    <footer>
        <p><a href="admin/indexadmin.php">Admin</a>
           <a href="indexApi.php">API</a></p>
            
        <p class="copyright">© 2018 BUF. UNIV LR- Tous droits réservés</p>
    </footer>
</body>

</html>
