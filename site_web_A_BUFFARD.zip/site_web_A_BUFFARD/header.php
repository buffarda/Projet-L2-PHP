<?php

    //session_start();
?>

<!DOCTYPE>
<html>
   <head>
    <title>Japan Expo hiver</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-tofit=no">
    <link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
    <link rel="icon" href="favicon.png" type="image/png">
    <link rel="icon" href="animated_favicon.gif" type="image/gif">
    <link rel="stylesheet" href="style/styleprinc.css">
    <link rel="stylesheet" href="style/reset.css">
    <link href="https://fonts.googleapis.com/css?family=Indie+Flower" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet">
</head>
    <body>
        <header>
        <img src="image/embleme_japan2.png" alt="embleme de la Japan Expo" />
        <h1>d'hiver</h1>
        <h2>du 26 au 29 décembre</h2>
        <nav>
            <input type="checkbox" id="menu">
            <ul>
                <?php if(isset($_SESSION['email'])&& !empty($_SESSION['email'])): ?>
                <li><a href='deconnexion.php'>Déconnexion</a></li>
                <?php endif; 
                    if(!isset($_SESSION['email']) || empty($_SESSION['email'])):?>
                <li><a href='Inscription1.php'>Inscription</a></li>
                <li><a href='login.php'>Connexion</a></li>
                <?php endif; ?>
                <li><a href="commande.php">Réserver</a></li>
                <li><a href="evenements.php">Événements</a></li>
                <li><a href="index.php">Accueil</a></li>
            </ul>

        </nav>
    </header>
    </body>
</html>